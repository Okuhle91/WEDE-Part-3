#PartTwoImprovements

1. From the feedback that I recieved from part 1 from my lecture, all was suppose to do on my part two was to add external CSS using this link tab: <link rel = "stylesheet" type = "text/CSS" href="CSS/style1.css">

2. For the final POE I am required to create a website using both HTML and CSS, then add some Java Script form validations

3. I have also added some date and time updates, which also has a welcome greeting, Homepage, "Showing Good morning/afternoon/evening!" based on the time of day

4. Form validation,Contact Us,"Checks all fields are filled, validates email format, and checks the phone number has at least 10 digits — with clear error messages in red, and a green success message using the visitor's name"

5. Gallery lightbox,Gallery,"Click any photo to view it full-screen, with ◀ ▶ arrows, an image counter (e.g. 3 / 16), close button, and keyboard support (Esc, arrow keys)"

6. Back-to-top button,All pages,"Smooth-scrolls to the top, appears after scrolling 300px"

7. Dynamic year,All pages,The © 2024 in your footer updates automatically every year

8. Also added my email in java script so that the information in the form may reflect to me

9. Also added other contacts social networks such as whats'app, facebook, and instagram, they're shown as icons below the footer.

10. I embedded a YouTube video also



References

https://www.w3schools.com/js/js_dates.asp

https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date

https://developer.mozilla.org/en-US/docs/Web/API/Element/classList
https://developer.mozilla.org/en-US/docs/Web/API/Window/location

https://developer.mozilla.org/en-US/docs/Learn/Forms/Form_validation

https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Regular_expressions

https://www.w3schools.com/js/js_validation.asp

https://formsubmit.co/ajax/.

https://formsubmit.co/ajax-documentation

https://formsubmit.co/documentation

https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch

https://developer.mozilla.org/en-US/docs/Web/API/EventTarget/addEventListener

https://developer.mozilla.org/en-US/docs/Web/API/KeyboardEvent

https://www.w3schools.com/howto/howto_js_lightbox.asp

https://developer.mozilla.org/en-US/docs/Web/API/Window/scrollTo

https://developer.mozilla.org/en-US/docs/Web/API/Element/scroll_event

https://developer.mozilla.org/en-US/docs/Web/API/Window/setInterval

https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date/toLocaleDateString

https://simpleicons.org/

https://faq.whatsapp.com/591339899867293